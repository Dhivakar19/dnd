export const COMPONENT_LABEL = {
    SUBMIT: "Submit",
    AGREE : "Agree",
    SELECT_DOB:"Select DOB",
    ENTER_TEXT:"Enter Text",
    HEADING:"Drag & Drop",
    UI_Element:"UI Element",
    BUILD_SECTION:"Build Section",
    CLEAR:"clear"
};



export const inputTypes = [
    { name: "Text", icon: "TextFieldsIcon" },
    { name: "DatePicker", icon: "CalendarTodayIcon" },
    { name: "CheckBox", icon: "CheckBoxIcon" },
    { name: "Button", icon: "CheckBoxOutlineBlankIcon" },
  ];


