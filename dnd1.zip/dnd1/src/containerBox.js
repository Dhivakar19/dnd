import InputElementBox from './draggable/InputElementBox';
import DroppableContainer from './draggable/DroppableContainer';
import React, { useState } from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import {COMPONENT_LABEL} from './labelConstant';

const useStyles = makeStyles(theme => ({
offset:theme.mixins.toolbar,
root: {
  flexGrow: 1, 
  backgroundColor:"#FF6602", 
},
appBarbg: {
  backgroundColor:"#1BB3F4", 
},
paper: {
  padding: theme.spacing(2),
  textAlign: 'center',
  color: theme.palette.text.secondary,
},
draggableRoot: {
  display: 'flex',
  flexWrap: 'wrap',
  '& > *': {
    margin: theme.spacing(2),
    width: theme.spacing(25),
    height: theme.spacing(40),
  },
},
text: {
  padding: theme.spacing(2, 2, 0),
  color: "black",
  fontWeight:2
},
headingColor:{
  color: "white",
  fontFamily:"Droid Serif"
},
elementPadding: {
  padding: theme.spacing(4, 2, 0),
},
droppableRoot: {
  display: 'flex',
  flexWrap: 'wrap',
  '& > *': {
    margin: theme.spacing(2),
    width: theme.spacing(80),
    height: theme.spacing(40),
  },
},
}))


const ContainerBox = () =>{
  const classes = useStyles();
const [draggedType, setDraggedType] = useState('');
const [revertBack, setRevertBack] = useState(false);



const setDraggedUiElementType = (typeName) => {
  setDraggedType(typeName);
  setRevertBack(false);
}

const clearAll = () => {
setRevertBack(true);
setDraggedType('');

}
  

  return (
    <React.Fragment>
      <AppBar color="inherint" className={classes.appBarbg} position="fixed">
        <Toolbar>
        <Typography variant="h5" className={classes.headingColor} component="h5">
      {COMPONENT_LABEL.HEADING}
          </Typography>
    </Toolbar>
      </AppBar>
      <div className={classes.offset}/>
      <div  className={classes.root}> 
      <Grid container spacing={4}>
        
        <Grid item xs={4} className={classes.draggableRoot}>
          <Paper   elevation={6} className={classes.paper}>
          <Typography className={classes.text} variant="h6" gutterBottom={true}>
       {COMPONENT_LABEL.UI_Element}
        </Typography>
        <InputElementBox classes={classes} revertBack={revertBack}  draggedType={draggedType} />
          </Paper>
        </Grid>
        <Grid item xs={8} className={classes.droppableRoot}>
          <Paper elevation={6} className={classes.paper}>
          <Typography className={classes.text} variant="h6" gutterBottom>
          {COMPONENT_LABEL.BUILD_SECTION}
        </Typography>
        <DroppableContainer revertBack={revertBack} setDraggedUiElementType={setDraggedUiElementType}/>
          </Paper>
        </Grid>
        <Grid item xs={7}></Grid>
        <Grid  item xs={4}>
        <Button
        variant="contained"
        color="primary"
        onClick={clearAll}
        startIcon={<DeleteForeverIcon />}
      >
        {COMPONENT_LABEL.CLEAR}
      </Button>
        </Grid>
      </Grid>
      </div>
     
    </React.Fragment>
  );

    }
export default ContainerBox;
