import React, { useRef } from "react";
import ElementDraggable from "../containerElementDraggable/ElementDraggable";
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import PropTypes from "prop-types";
import {COMPONENT_LABEL} from "../labelConstant";

const DraggableContainerElement = ({type}) => {
  const elementRef = useRef(null);
  ElementDraggable(elementRef);

  const inputElementRender = (type) => {
    switch (type) {
      case 'Text':
        return <TextField id="outlined-basic" label={COMPONENT_LABEL.ENTER_TEXT} variant="outlined" />;
      case 'DatePicker':
        return <TextField
          id="date"
          label={COMPONENT_LABEL.SELECT_DOB}
          type="date"
          defaultValue="2017-05-24"
        />;
      case "CheckBox":
        return <FormControlLabel
          control={
            <Checkbox
              checked={false}
              name="checkAdult"
              color="secondary"
            />
          }
          label={COMPONENT_LABEL.AGREE}
        />;
      case "Button":
        return <Button
          id="draggableButton"
          variant="contained"
          color="primary"
        >  {COMPONENT_LABEL.SUBMIT}
   </Button>;
      default:
        return null;
    }


  }

  return (
    <div key={type} ref={elementRef}>
      {type ? inputElementRender(type) : <></>}
    </div>
  );
};

DraggableContainerElement.propTypes = {
  type: PropTypes.string.isRequired,
}

export default DraggableContainerElement;