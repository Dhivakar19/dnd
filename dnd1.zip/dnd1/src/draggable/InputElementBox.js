import React, { useState, useEffect } from 'react';
import TextFieldsIcon from '@material-ui/icons/TextFields';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CalendarTodayIcon from '@material-ui/icons/CalendarToday';
import Chip from '@material-ui/core/Chip';
import PropTypes from "prop-types";
import {inputTypes} from '../labelConstant';

const InputElementBox = ({ draggedType, revertBack, classes }) => {

  const [elemenetList, setElemenetList] = useState(inputTypes);

  useEffect(() => {
    onDropRemove(draggedType)
  }, [draggedType])

  useEffect(() => {
    handleRevertBack(revertBack)
  }, [revertBack])


  const onDragStart = (event, typeName) => {
    event.dataTransfer.setData("typeName", typeName);
  }

  const onDropRemove = (typeName) => {
    let updatedList = elemenetList.filter(element => element.name !== typeName);
    setElemenetList(updatedList);
  }

  const onHandleIcon = (iconName) => {
    switch (iconName) {
      case 'TextFieldsIcon':
        return <TextFieldsIcon />;
      case 'CalendarTodayIcon':
        return <CalendarTodayIcon />;
      case "CheckBoxIcon":
        return <CheckBoxIcon />;
      case "CheckBoxOutlineBlankIcon":
        return <CheckBoxOutlineBlankIcon />;
      default:
        return <CheckBoxOutlineBlankIcon />;
    }

  }

  const handleRevertBack = (revertFlag) => {
    if (revertFlag) {
      setElemenetList(inputTypes);
    }
  }

  return (
    elemenetList && elemenetList.map(
      (type, index) => (
        <div id={type.name}
          onDragStart={(event) => onDragStart(event, type.name)} className={classes.elementPadding}
          draggable
        >
          <Chip
            size="small"
            color="primary"
            icon={onHandleIcon(type.icon)}
            label={type.name}
          />
        </div>
      ))
  )





  

}




InputElementBox.propTypes = {
  draggedType: PropTypes.string.isRequired,
  revertBack: PropTypes.bool.isRequired,
  classes: PropTypes.object.isRequired
}


export default InputElementBox;
