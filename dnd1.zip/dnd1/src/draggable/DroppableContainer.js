import React, { useState, useEffect } from 'react';
import Container from '@material-ui/core/Container';
import Typography from '@material-ui/core/Typography';
import DraggableContainerElement from './DraggableContainerElement';
import PropTypes from "prop-types";


const DroppableContainer = ({revertBack,setDraggedUiElementType}) => {

  const [draggedElementName, setDraggedElementName] = useState([]);

  useEffect(() => {
    handleRevertBack(revertBack)
}, [revertBack])

const handleRevertBack = (revertFlag) => {
  if(revertFlag){
    setDraggedElementName([])
  }
}

  const onDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
  }

  const onDrop = (event) => {
    let typeName = event.dataTransfer.getData("typeName");
    setDraggedUiElementType(typeName);
    setDraggedElementName(oldElements => [...oldElements, typeName]);
  }
  return (
    <React.Fragment>
      <Container fixed onDragOver={(event) => onDragOver(event)}
        onDrop={(event) => onDrop(event)}
      >
       <Typography style={{ backgroundColor: 'white', height: '37vh' }} >
          {draggedElementName.map(value => {
            return <DraggableContainerElement type={value} key={value} />
          })}
        </Typography>
      </Container>
    </React.Fragment>
  )
}

DroppableContainer.propTypes = {
  revertBack: PropTypes.bool.isRequired,
  setDraggedUiElementType: PropTypes.func.isRequired
}

export default DroppableContainer;