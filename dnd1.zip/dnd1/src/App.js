
import React  from 'react';
import ContainerBox from './containerBox';



const App = (props) =>{

  return (
    <ContainerBox/>
  );

    }
export default App;
