import React, { Component } from "react";

export default class Filter extends Component {
  render() {
    return (
      <div className="filter">
        <div className="filter-result">{this.props.count} Products</div>
        <div className="filter-sort">
          Category{" "}
          <select value={this.props.category} onChange={this.props.selectCategory}>
            <option>ALL</option>
            <option value="Console">Console</option>
            <option value="Controller">Controller</option>
          </select>
        </div>

        { this.props.category ==='Console' && <div className="filter-size">
          Memory Size{" "}
          <select value={this.props.size} onChange={this.props.filterMemeorySize}>
            <option value="">ALL</option>
            <option value="200GB">200GB</option>
            <option value="500GB">500GB</option>
            <option value="1TB">1TB</option>
          </select>
    </div> }

        <div className="filter-sort">
          Price{" "}
          <select value={this.props.sort} onChange={this.props.sortProducts}>
            <option>Latest</option>
            <option value="lowest">Lowest</option>
            <option value="highest">Highest</option>
          </select>
        </div>
    
      </div>
    );
  }
}