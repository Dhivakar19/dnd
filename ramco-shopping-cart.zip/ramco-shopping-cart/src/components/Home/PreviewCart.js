import React,{useState,useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import CardActions from '@material-ui/core/CardActions';
import CardHeader from '@material-ui/core/CardHeader';
import Button from '@material-ui/core/Button';
import Avatar from '@material-ui/core/Avatar';
import { red } from '@material-ui/core/colors';
import ShoppingCartSharpIcon from '@material-ui/icons/ShoppingCartSharp';
import {  Card } from '@material-ui/core';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
const useStyles = makeStyles({
    root: {
        minWidth: 270,
    },
    title: {
        fontSize: 24,
    },
    headerTitle: {
        fontSize: `30px`,
    },
    pos: {
        marginBottom: 12,
    },
    moveLeft:{
        marginLeft:`90px`
    },
    avatar: {
        backgroundColor: red[500],
    },
});

const PreviewCart = ({ cartItems,history }) => {
    const classes = useStyles();
    const [state, setState] = useState({
        open: false,
        vertical: 'top',
        horizontal: 'center',
      });
      const [totalItemCount, setTotalItemCount] = useState(0);

      useEffect(() => {
      let total =0;
      cartItems && cartItems.forEach(product => {
        total+=product.count
    });
    setTotalItemCount(total);
     
  }, [cartItems])

  

      const { vertical, horizontal, open } = state;

    const handleCheckout = () =>{
        const newState = { vertical: 'top', horizontal: 'center' }
        cartItems.length!==0 ? history.push('/checkout') : setState({ open: true, ...newState });
    }

    
    const  Alert = (props) => {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
      }


  const handleClose = () => {
    setState({ ...state, open: false });
  };


 

    return (
        <>
     <Card className={classes.root} >
            <CardHeader className={classes.headerTitle}
                avatar={
                    <Avatar aria-label="recipe" className={classes.avatar}>
                         K
          </Avatar>
                }
                titleTypographyProps={{ variant: 'h4' }}
                subheaderTypographyProps={{ variant: 'h5' }}
                subheader={`item in Cart: ${totalItemCount}`}
                title="Cart Preview"

            />
            <CardActions className={classes.moveLeft}>
                <Button size="large" variant="contained" color="primary"  startIcon={<ShoppingCartSharpIcon />} onClick = {handleCheckout} >Checkout</Button>
            </CardActions>
        </Card>
        <Snackbar open={open} anchorOrigin={{ vertical, horizontal }} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="warning">
        Add Prouct to Cart
        </Alert>
      </Snackbar>
      </>
    );
}
export default PreviewCart;
