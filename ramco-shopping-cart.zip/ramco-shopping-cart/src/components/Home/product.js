import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Rating from '@material-ui/lab/Rating';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';


const useStyles = makeStyles({
    root: {
        maxWidth: 330,
        height: "100%",
      },
      media: {
        height: 0,
        paddingTop: '40.25%', // 16:9
      },
  text:{
      fontSize:11
  }
});

const  ProductCard = ({product,addToCart}) => {
  const classes = useStyles();

  return (
      
    <Card className={classes.root}>
      <CardActionArea>
        <CardMedia
          className={classes.media}
          image={product.image}
          title= {product.title}
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="h2">
          {product.title}
          </Typography>
          <Typography gutterBottom variant="body2" color="textSecondary" component="p">
           {product.description}
          </Typography>
          <Typography  variant="h5" component="h2">
          &#x20b9; {product.price}
          </Typography>
          <Rating name="read-only" value={product.rating} readOnly />
        </CardContent>
      </CardActionArea>
      <CardActions>
        <Button size="small" color="primary"  className={classes.text} endIcon={<AddShoppingCartIcon/>} onClick={() => addToCart(product)}>
         Add to Cart
        </Button>
      </CardActions>
    </Card>
  );
}


export default  ProductCard;
