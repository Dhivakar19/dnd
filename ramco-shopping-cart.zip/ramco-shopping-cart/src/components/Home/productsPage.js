import React, { useState } from 'react'
import { Grid} from '@material-ui/core';
import LandingPageHeader from "../HeaderAndFooter/landingPageHeader";
import LandingPageFooter from "../HeaderAndFooter/landingPageFooter";
import Filters from "./filters";
import ProductCard from "./product";
import PreviewCart from './PreviewCart'
import { makeStyles } from '@material-ui/core/styles';



const useStyles = makeStyles((theme) => ({

    toolbar: {
        minHeight: `95px`
    },
    root: {
        flexGrow: 1,
    },
    cardRoot: {
        maxWidth: 345,
      },


}));


            



const ProductsPage = ({ products, addToCart, size, count, cartItems,removeFromCart,createOrder,sort, filterMemeorySize, sortProducts,
    selectCategory, category, history}) => {
    const classes = useStyles();

    return (
        <React.Fragment>
            <div className={classes.root}>
                <Grid container >
                    <Grid xs={12} item>
                        <LandingPageHeader history={history} />
                    </Grid>
                    <Grid xs={12} container item>
                        <Grid xs={8} sm={6} md={3} item />
                        <Grid xs={4} sm={6} md={8} container item>
                            <Filters size={size} sort={sort}
                                filterMemeorySize={filterMemeorySize}
                                sortProducts={sortProducts}
                                selectCategory={selectCategory}
                                category={category} />
                        </Grid>

                    </Grid>
                    <div className={classes.toolbar} />
                    <Grid container spacing={4} item xs={12} sm={10} md={8} >
                        {products.map((product) => (
                            <Grid key={product._id} item xs={12} sm={8} md={4}>
                                <ProductCard key={product._id} addToCart={addToCart} product={product} />
                            </Grid>
                        ))}

                    </Grid>
                    <Grid container  item xs={12} sm={1} md={1} />      
                    <Grid  spacing={1} item xs={12} sm={1} md={3} >
                        <PreviewCart cartItems={cartItems}
                            removeFromCart={removeFromCart}
                            createOrder={createOrder}
                            history={history}/>
                    </Grid>
                    <Grid xs={12} item>
                        <LandingPageFooter />
                    </Grid>
                </Grid>
            </div>
        </React.Fragment>
    );

}

export default ProductsPage; 