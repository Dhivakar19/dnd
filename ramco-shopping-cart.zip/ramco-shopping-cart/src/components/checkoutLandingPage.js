import React,{useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import AddressForm from './AddressForm';
import PaymentForm from './PaymentForm';
import OrderReview from './OrderReview';
import LandingPageHeader from "./landingPageHeader";
import LandingPageFooter from "./landingPageFooter";
import HomeIcon from '@material-ui/icons/Home';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';



const useStyles = makeStyles((theme) => ({
  appBar: {
    position: 'relative',
  },
  layout: {
    width: 'auto',
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
    [theme.breakpoints.up(600 + theme.spacing(2) * 2)]: {
      width: 600,
      marginLeft: 'auto',
      marginRight: 'auto',
    },
  },
  paper: {
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(3),
    padding: theme.spacing(2),
    [theme.breakpoints.up(600 + theme.spacing(3) * 2)]: {
      marginTop: theme.spacing(6),
      marginBottom: theme.spacing(6),
      padding: theme.spacing(3),
    },
  },
  stepper: {
    padding: theme.spacing(3, 0, 5),
  },
  buttons: {
    display: 'flex',
    justifyContent: 'flex-end',
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
}));




const CheckoutLandingPage = ({cartItems,removeFromCart,createOrder,history}) => {
  const classes = useStyles();
  const [activeStep, setActiveStep] = useState(0);
  const [snack, setSnackBarState] = useState({
    open: false,
    vertical: 'top',
    horizontal: 'center',
  });
  const [addressDetails, setStateAddressDetails] = useState({});
  const [paymentDetails, setStatePaymentDetails] = useState({});

  const steps = ['Shipping address', 'Payment details', 'Review your order'];

const  getStepContent = (step) => {
  switch (step) {
    case 0:
      return <AddressForm handleAddressDetails={handleAddressDetails} />;
    case 1:
      return <PaymentForm handlePaymentDetails={handlePaymentDetails} />;
    case 2:
      return <OrderReview cartItems={cartItems}
      removeFromCart={removeFromCart}
      createOrder={createOrder}
      addressDetails={addressDetails}
      paymentDetails={paymentDetails}
     />;
    default:
      throw new Error('Unknown step');
  }
}

  

  const { vertical, horizontal, open } = snack;

  const handleAddressDetails = (details) => {
    setStateAddressDetails({ ...details});
    console.log("@@Cont",addressDetails)
    };

    const handlePaymentDetails = (payDetails) => {
      setStatePaymentDetails({ ...payDetails});
      console.log("@@paymentDetails",paymentDetails)
      };
    

const handleNext = () =>{
    const newState = { vertical: 'top', horizontal: 'center' }
    cartItems.length!==0 ?  setActiveStep(activeStep + 1)  : setSnackBarState({ open: true, ...newState });;
}

const  Alert = (props) => {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

const handleClose = () => {
setSnackBarState({ ...snack, open: false });
};

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };
  const handleGoToProduct = () => {
    history.goBack();
  };

  

  return (
    <React.Fragment>
   <LandingPageHeader history={history} />
      <main className={classes.layout}>
        <Paper className={classes.paper}>
          
        <Button onClick={handleGoToProduct} 
          variant="contained"
          color="secondary" align="left"  startIcon={<HomeIcon />} className={classes.button}>
                      Home
                    </Button>
          <Typography component="h1" variant="h4" align="center">
            Checkout
          </Typography>
          <Stepper activeStep={activeStep} className={classes.stepper}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          <React.Fragment>
            {activeStep === steps.length ? (
              <React.Fragment>
                <Typography variant="h5" gutterBottom>
                  Thank you for your order.
                </Typography>
                <Typography variant="subtitle1">
                  Your order number is #2001539. We have emailed your order confirmation, and will
                  send you an update when your order has shipped.
                </Typography>
              </React.Fragment>
            ) : (
              <React.Fragment>
                {getStepContent(activeStep)}
                <div className={classes.buttons}>
                  {activeStep !== 0 && (
                    <Button onClick={handleBack} className={classes.button}>
                      Back
                    </Button>
                  )}
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleNext}
                    className={classes.button}
                  >
                    {activeStep === steps.length - 1  ? 'Place order' : 'Next'}
                  </Button>
                </div>
              </React.Fragment>
            )}
          </React.Fragment>
        </Paper>
      </main>
      <LandingPageFooter/>
      <Snackbar open={open} anchorOrigin={{ vertical, horizontal }} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="warning">
       Your Cart is Empty. Kindly Place an order !!
        </Alert>
      </Snackbar>
    </React.Fragment>
  );
}

export default  CheckoutLandingPage;