import React,{useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import Button from '@material-ui/core/Button';
import Avatar from '@material-ui/core/Avatar';
import { red } from '@material-ui/core/colors';
import ShoppingCartSharpIcon from '@material-ui/icons/ShoppingCartSharp';
import { Grid, Card } from '@material-ui/core';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
const useStyles = makeStyles({
    root: {
        minWidth: 270,
    },
    title: {
        fontSize: 24,
    },
    headerTitle: {
        fontSize: `30px`,
    },
    pos: {
        marginBottom: 12,
    },
    moveLeft:{
        marginLeft:`90px`
    },
    avatar: {
        backgroundColor: red[500],
    },
});

const PreviewCartSection = ({ cartItems,history }) => {
    const classes = useStyles();
    const [state, setState] = useState({
        open: false,
        vertical: 'top',
        horizontal: 'center',
      });

      const { vertical, horizontal, open } = state;

    const handleCheckout = () =>{
        const newState = { vertical: 'top', horizontal: 'center' }
        cartItems.length!==0 ? history.push('/checkout') : setState({ open: true, ...newState });
    }

    
    const  Alert = (props) => {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
      }


  const handleClose = () => {
    setState({ ...state, open: false });
  };

    return (
        <>
     <Card className={classes.root} >
            <CardHeader className={classes.headerTitle}
                avatar={
                    <Avatar aria-label="recipe" className={classes.avatar}>
                        D
          </Avatar>
                }
                titleTypographyProps={{ variant: 'h3' }}
                subheaderTypographyProps={{ variant: 'h3' }}
                subheader={`item in Cart: ${cartItems.length}`}
                title="Cart Preview"

            />
            {/* <CardContent>
                {cartItems.map((item) => (
                   
                    <Grid key={item._id} item xs={12} sm={11} md={9}>
                        <CartItemProduct key={item._id} product={item} />
                    </Grid>
                ))}


            </CardContent> */}
            <CardActions className={classes.moveLeft}>
                <Button size="large" variant="contained" color="primary"  startIcon={<ShoppingCartSharpIcon />} onClick = {handleCheckout} >Checkout</Button>
            </CardActions>
        </Card>
        <Snackbar open={open} anchorOrigin={{ vertical, horizontal }} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="warning">
        Add Prouct to Cart
        </Alert>
      </Snackbar>
      </>
    );
}
export default PreviewCartSection;
