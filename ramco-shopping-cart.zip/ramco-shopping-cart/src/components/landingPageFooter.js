  
import React from 'react';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Link from '@material-ui/core/Link';
import red from '@material-ui/core/colors/red';



const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
    minHeight: '10vh',
    marginTop: theme.spacing(12),
  },
  footerTextColor: {
    color: "black",
    fontFamily: "Droid Serif",
    fontWeight: 25,
    fontSize:`12px`
  },
  footer: {
    padding: theme.spacing(3, 2),
    backgroundColor: "#f5f5f5",
  },
}));



const LandingPageFooter = () => {
  const classes = useStyles();

  const  Copyright = () => {
    return (
      <Typography variant="body2" className={classes.footerTextColor}>
        {`Copyright © Game Zone ${new Date().getFullYear()}.`}
      </Typography>
    );
  }
  

  return (
    <div className={classes.root}>
      {/* <CssBaseline /> */}
      
      <footer className={classes.footer}>
        <Container maxWidth="sm">
          <Copyright />
        </Container>
      </footer>
    </div>
  );
}

export default  LandingPageFooter;