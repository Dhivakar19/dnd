import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import{Grid,AppBar,Toolbar,Typography} from '@material-ui/core';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';

const useStyles = makeStyles((theme) => ({
 
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
      },
      filterSize:{
        fontSize:15,
      }
}));

const LandingPageFilter = ({count,size,sort,filterMemeorySize,sortProducts,
    selectCategory,category}) => {
  const classes = useStyles();

  return (
    <React.Fragment>
        <Grid  xs={2} sm={2} md={3} item>
        <InputLabel className={classes.filterSize}  htmlFor="age-native-simple">Category</InputLabel>
        <FormControl className={classes.formControl}>
        <Select
          native
          value={category} onChange={selectCategory}>
            <option>ALL</option>
            <option value="Console">Console</option>
            <option value="Controller">Controller</option>

        </Select>
      </FormControl>
        </Grid>
        { category ==='Console' &&  <Grid  xs={1} sm={2} md={3} item>
        <InputLabel className={classes.filterSize}  htmlFor="age-native-simple"> Memory Size</InputLabel>
        <FormControl className={classes.formControl}>
        <Select
          native
          value={size} onChange={filterMemeorySize}>
            <option value="">ALL</option>
            <option value="200GB">200GB</option>
            <option value="500GB">500GB</option>
            <option value="1TB">1TB</option>
        </Select>
      </FormControl>
  
            </Grid>}
        <Grid className={classes.backGroundsidebar} xs={1} sm={2} md={2} item>
        <InputLabel className={classes.filterSize}  htmlFor="age-native-simple">Price</InputLabel>
        <FormControl className={classes.formControl}>
        <Select
          native
          value={sort} onChange={sortProducts}
        >
            <option>Latest</option>
            <option value="lowest">Lowest</option>
            <option value="highest">Highest</option>
        </Select>
      </FormControl>
  
        </Grid>
        
     
    </React.Fragment>
  );
}

export default  LandingPageFilter;
