import React,{useState}from 'react';
import { makeStyles } from '@material-ui/core/styles';
import{Grid,AppBar,Toolbar,Typography} from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormGroup from '@material-ui/core/FormGroup';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';

const useStyles = makeStyles((theme) => ({
 
  menuButton: {
    marginRight: theme.spacing(2),
  },
  root: {
    flexGrow: 1,
  },
  moveLeft:{
    // marginLeft:`1200px`
  },
  title: {
   fontFamily:'Cardo',
   flexGrow: 1,
  },
  toolbar: {
    minHeight:`35px`
  },
  appBarbg: {
    backgroundColor: "#1565c0",
    fontWeight: 2
  },
}));

const LandingPageHeader = ({history}) => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

 
  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  }

   const handleLogOut = () => {
history.push('/');
   }

   const handleBack = () => {
    history.goBack();
       }

  return (
    <div className={classes.root}>
      <AppBar className={classes.appBarbg}  position="static">
      <Toolbar>
          <IconButton edge="start"  onClick={handleBack} className={classes.menuButton} color="inherit" aria-label="menu">
            <ArrowBackIosIcon />
          </IconButton>
          <Typography variant="h4" align="center" className={classes.title}>
            Game Zone
          </Typography>
            <div className={classes.moveLeft}>
              <IconButton
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                color="inherit"
                edge="end"
              >
                <AccountCircle />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                keepMounted
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                open={open}
                onClose={handleClose}
              >
                <MenuItem onClick={handleLogOut}>LogOut</MenuItem>
              </Menu>
            </div>
          
        </Toolbar>
      </AppBar>
      <div className={classes.toolbar} />
    </div>
  );
}

export default  LandingPageHeader;
