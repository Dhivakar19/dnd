import React, { useState, useEffect } from 'react'
import { Grid, AppBar, Toolbar, Typography, Card } from '@material-ui/core';
import LandingPageHeader from "./landingPageHeader";
import LandingPageFooter from "./landingPageFooter";
import LandingPageFilter from "./landingFilter";
import ProductCard from "./productCard";
import PreviewCartSection from './PreviewCartSection'
import { makeStyles } from '@material-ui/core/styles';
import Divider from '@material-ui/core/Divider'



const useStyles = makeStyles((theme) => ({

    toolbar: {
        minHeight: `95px`
    },
    root: {
        flexGrow: 1,
    },
    cardRoot: {
        maxWidth: 345,
      },


}));


            



const LandingPage = ({ products, addToCart, size, count, cartItems,removeFromCart,createOrder,sort, filterMemeorySize, sortProducts,
    selectCategory, category, history}) => {
    const classes = useStyles();
    const [state, setState] = useState({
        age: '',
        name: 'hai',
    });

    const handleChange = (event) => {
        const name = event.target.name;
        setState({
            ...state,
            [name]: event.target.value,
        });
    };
    return (
        <React.Fragment>
            <div className={classes.root}>
                <Grid container >
                    <Grid xs={12} item>
                        <LandingPageHeader history={history} />
                    </Grid>
                    <Grid xs={12} container item>
                        <Grid xs={8} sm={6} md={4} item />
                        <Grid xs={4} sm={6} md={8} container item>
                            <LandingPageFilter size={size} sort={sort}
                                filterMemeorySize={filterMemeorySize}
                                sortProducts={sortProducts}
                                selectCategory={selectCategory}
                                category={category} />
                        </Grid>

                    </Grid>
                    <div className={classes.toolbar} />
                    <Grid container spacing={4} item xs={12} sm={10} md={8} >
                        {products.map((product) => (
                            <Grid key={product._id} item xs={12} sm={8} md={4}>
                                <ProductCard key={product._id} addToCart={addToCart} product={product} />
                            </Grid>
                        ))}

                    </Grid>
                    <Grid container  item xs={12} sm={1} md={1} />
                  
                    {/* <Divider orientation="vertical" flexItem /> */}
                       
                    <Grid  spacing={1} item xs={12} sm={1} md={3} >
                   
                        <PreviewCartSection cartItems={cartItems}
                            removeFromCart={removeFromCart}
                            createOrder={createOrder}
                            history={history}/>
                       

                    </Grid>

                    <Grid xs={12} item>
                        <LandingPageFooter />
                    </Grid>


                </Grid>
            </div>
        </React.Fragment>
    );

}

export default LandingPage; 