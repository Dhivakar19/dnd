import React,{useState} from 'react';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

const AddressForm = ({handleAddressDetails}) => {

    const [addressDetails,setAddressDetails] = useState({
        firstName:'',
        lastName:'',
        add1:'',
        add2:'',
        city:'',
        state:'',
        country:'',
        city:'',
        zipCode:''
    })

    const {firstName,
    lastName,
    add1,
    add2,
    city,
    state,
    country,
    zipCode} = addressDetails

    const handleFirstName = (e) =>{
        setAddressDetails({ ...addressDetails, firstName: e.target.value });
        handleAddressDetails(addressDetails);
    }
    const handleLastName = (e) =>{
        setAddressDetails({ ...addressDetails, lastName: e.target.value });
        handleAddressDetails(addressDetails);
    }
    const handleAdd1 = (e) =>{
        setAddressDetails({ ...addressDetails, add1: e.target.value });
        handleAddressDetails(addressDetails);
    }
    const handleAdd2 = (e) =>{
        setAddressDetails({ ...addressDetails, add2: e.target.value });
        handleAddressDetails(addressDetails);
    }
    const handlecity = (e) =>{
        setAddressDetails({ ...addressDetails, city: e.target.value });
        handleAddressDetails(addressDetails);
    }
    const handleState = (e) =>{
        setAddressDetails({ ...addressDetails, state: e.target.value });
        handleAddressDetails(addressDetails);
    }
    const handlCode = (e) =>{
        setAddressDetails({ ...addressDetails, zipCode: e.target.value });
        handleAddressDetails(addressDetails);
    }
    const handleCountry = (e) =>{
        setAddressDetails({ ...addressDetails, country: e.target.value });
        handleAddressDetails(addressDetails);
    }

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Shipping address
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="firstName"
            name="firstName"
            label="First name"
            fullWidth
            value={firstName}
            onChange={(e) => handleFirstName(e)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="lastName"
            name="lastName"
            label="Last name"
            fullWidth
            value={lastName}
            autoComplete="family-name"
            onChange={(e) => handleLastName(e)}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            required
            id="address1"
            name="address1"
            label="Address line 1"
            fullWidth
            value={add1}
            autoComplete="shipping address-line1"
            onChange={(e) => handleAdd1(e)}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            id="address2"
            name="address2"
            label="Address line 2"
            fullWidth
            autoComplete="shipping address-line2"
            value={add2}
            onChange={(e) => handleAdd2(e)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="city"
            name="city"
            label="City"
            fullWidth
            autoComplete="shipping address-level2"
            value={city}
            onChange={(e) => handlecity(e)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField id="state" name="state" label="State" value={state}
          onChange={(e) => handleState(e)} fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="zip"
            name="zip"
            label="Zip / Postal code"
            fullWidth
            autoComplete="shipping postal-code"
            value={zipCode}
            onChange={(e) => handlCode(e)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="country"
            name="country"
            label="Country"
            fullWidth
            autoComplete="shipping country"
            value={country}
            onChange={(e) => handleCountry(e)}
          />
        </Grid>
        <Grid item xs={12}>
          <FormControlLabel
            control={<Checkbox color="secondary" name="saveAddress" value="yes" />}
            label="Use this address for payment details"
          />
        </Grid>
      </Grid>
    </React.Fragment>
  );
}

export default  AddressForm;
