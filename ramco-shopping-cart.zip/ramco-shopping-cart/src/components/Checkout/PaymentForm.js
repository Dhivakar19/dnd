import React,{useState} from 'react';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

const PaymentForm = ({handlePaymentDetails}) => {

    const [payDetails,setPayDetails] = useState({
        cardName:'',
        cardNum:'',
        expiryDate:'',
        cvv:'',
        
    })

    
    const handleCardName = (e) =>{
        setPayDetails({ ...payDetails, cardName: e.target.value });
        handlePaymentDetails(payDetails);
    }
    const handleCardNum = (e) =>{
        setPayDetails({ ...payDetails, cardNum: e.target.value });
        handlePaymentDetails(payDetails);
    }
    const handleExpiryDate = (e) =>{
        setPayDetails({ ...payDetails, expiryDate: e.target.value });
        handlePaymentDetails(payDetails);
    }
    const handleCvv = (e) =>{
        setPayDetails({ ...payDetails, cvv: e.target.value });
        handlePaymentDetails(payDetails);
    }

    const { caredName,
    cardNum,
    expiryDate,
    cvv,} = payDetails

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Payment method
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <TextField required id="cardName" label="Name on card"
            value={caredName}
            onChange={(e) => handleCardName(e)}
             fullWidth autoComplete="cc-name" />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            required
            id="cardNumber"
            label="Card number"
            fullWidth
            autoComplete="cc-number"
            value={cardNum}
            onChange={(e) => handleCardNum(e)}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField required id="expDate" label="Expiry date"
            value={expiryDate}
            onChange={(e) => handleExpiryDate(e)} fullWidth autoComplete="cc-exp" />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            required
            id="cvv"
            value={cvv}
            onChange={(e) => handleCvv(e)}
            label="CVV"
            helperText="Last three digits on signature strip"
            fullWidth
            autoComplete="cc-csc"
          />
        </Grid>
        <Grid item xs={12}>
          <FormControlLabel
            control={<Checkbox color="secondary" name="saveCard" value="yes" />}
            label="Remember credit card details for next time"
          />
        </Grid>
      </Grid>
    </React.Fragment>
  );
}

export default  PaymentForm;