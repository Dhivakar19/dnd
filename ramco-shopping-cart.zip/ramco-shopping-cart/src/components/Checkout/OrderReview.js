import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import Grid from '@material-ui/core/Grid';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';




const useStyles = makeStyles((theme) => ({
  listItem: {
    padding: theme.spacing(1, 0),
  },
  total: {
    fontWeight: 700,
  },
  margin: {
    margin: theme.spacing(1),
  },
  title: {
    marginTop: theme.spacing(2),
  },
}));

const OrderReview = ({cartItems,removeFromCart,createOrder,addressDetails,paymentDetails}) => {
  const classes = useStyles();
const payments = [
  { name: 'Card type', detail: paymentDetails ? paymentDetails.cardName : ''},
  { name: 'Card holder', detail: addressDetails ? addressDetails.firstName: '' },
  { name: 'Card number', detail: paymentDetails ? paymentDetails.cardNum: '' },
  { name: 'Expiry date', detail: paymentDetails ?paymentDetails.expiryDate : ''},
];


  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Order summary
      </Typography>
      <List disablePadding>
        {cartItems.map((product) => (
          <ListItem className={classes.listItem} key={product._id}>
              <ListItemAvatar>
              <Avatar
                alt={product.title}
                src={product.image}
              />
            </ListItemAvatar>
            <ListItemText primary={product.title} secondary={product.description} />
            <Typography variant="body2">&#x20b9;{product.price} x {product.count}{" "}</Typography>
            <IconButton aria-label="delete" onClick={() => removeFromCart(product)} className={classes.margin}>
          <DeleteIcon fontSize="small" />
        </IconButton>
          </ListItem>
        ))}
        <ListItem className={classes.listItem}>
          <ListItemText primary="Total" />
          <Typography variant="subtitle1" className={classes.total}>
                      &#x20b9;{
                        cartItems.reduce((a, c) => a + c.price * c.count, 0)
                      }
          </Typography>
        </ListItem>
      </List>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6" gutterBottom className={classes.title}>
            Shipping
          </Typography>
         {addressDetails &&  (<><Typography gutterBottom>{addressDetails.firstName}</Typography>
          <Typography gutterBottom>{Object.values(addressDetails).slice(2).join(', ')}</Typography></>)}
        </Grid>
        <Grid item container direction="column" xs={12} sm={6}>
          <Typography variant="h6" gutterBottom className={classes.title}>
            Payment details
          </Typography>
          <Grid container>
            {payments.map((payment) => (
              <React.Fragment key={payment.name}>
                <Grid item xs={6}>
                  <Typography gutterBottom>{payment.name}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography gutterBottom>{payment.detail}</Typography>
                </Grid>
              </React.Fragment>
            ))}
          </Grid>
        </Grid>
      </Grid>
    </React.Fragment>
  );
}

export default  OrderReview;
