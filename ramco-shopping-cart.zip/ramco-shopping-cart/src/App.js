import React from "react";
import data from "./data.json";
import msgReply from './msg.json'
import ProductPage from "./components/Home/productsPage";
import CheckoutLandingPage from "./components/Checkout/checkoutLandingPage";
import SignInPage from './components/LandingPage/signIn';
import { Switch,Route } from "react-router-dom";
import { Widget,addResponseMessage } from 'react-chat-widget';
import 'react-chat-widget/lib/styles.css';
import './widgetsCss.css';

import logo from './logo/kratos.jpg';

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      products: data.products,
      size: "",
      sort: "",
      category:"",
      price:"",
      cartItems: [],
    };
  }


  
  removeFromCart = (product) => {
    const cartItems = this.state.cartItems.slice();
    this.setState({
      cartItems: cartItems.filter((x) => x._id !== product._id),
    });
  };

  createOrder = () => {
    this.setState({
      cartItems: [],
    });
  };

  addToCart = (product) => {
    const cartItems = this.state.cartItems.slice();
    let alreadyInCart = false;
    cartItems.forEach((item) => {
      if (item._id === product._id) {
        item.count++;
        alreadyInCart = true;
      }
    });
    if (!alreadyInCart) {
      cartItems.push({ ...product, count: 1 });
    }
    this.setState({ cartItems });
  };

  sortProducts = (event) => {
    const sort = event.target.value;
    this.setState((state) => ({
      sort: sort,
      products: this.state.products
        .slice()
        .sort((a, b) =>
          sort === "lowest"
            ? a.price > b.price
              ? 1
              : -1
            : sort === "highest"
            ? a.price < b.price
              ? 1
              : -1
            : a._id < b._id
            ? 1
            : -1
        ),
    }));
  };

  
  filterMemeorySize = (event) => {
    if (event.target.value === "") {
      this.setState({ size: event.target.value, products: data.products });
    } else {
      let productFilter= data.products.filter(
        (product) => product.availableMemory.indexOf(event.target.value) >= 0
      )
      const sort = this.state.sort;
      this.setState({
        size: event.target.value,
        products:productFilter
        .slice()
        .sort((a, b) =>
          sort === "lowest"
            ? a.price > b.price
              ? 1
              : -1
            : sort === "highest"
            ? a.price < b.price
              ? 1
              : -1
            : a._id < b._id
            ? 1
            : -1
        ),
      });
    }
  };

  selectCategory = (event) => {
    if (event.target.value === "ALL") {
      this.setState({ category: event.target.value, products: data.products, size:"ALL"});
    } else {
      this.setState({
        category: event.target.value,
        size: this.state.size,
        sort: this.state.sort,
        products: data.products.filter(
          (product) => product.Category === event.target.value
        ),
      });
    }
  };


  componentWillUnmount(){
    addResponseMessage('');
  }

  componentDidMount(){
    addResponseMessage('Welcome to GAME ZONE');
  }
  

   handleNewUserMessage = (newMessage) => {
     let response = msgReply[newMessage.replaceAll(' ','').toLowerCase()]
     response ? addResponseMessage(response) : addResponseMessage(`Sorry i didn't get you !`) ;
  };
  

  
  addToCart = (product) => {
    const cartItems = this.state.cartItems.slice();
    let alreadyInCart = false;
    cartItems.forEach((item) => {
      if (item._id === product._id) {
        item.count++;
        alreadyInCart = true;
      }
    });
    if (!alreadyInCart) {
      cartItems.push({ ...product, count: 1 });
    }
    this.setState({ cartItems });
  };

  render() {
    return (
<>

      <Switch>
      

      <Route exact path='/' render={(props) => <SignInPage
      
        {...props}/>}/>
     
        <Route exact path='/landing' render={(props) => 
        <>
        <ProductPage products={this.state.products} addToCart={this.addToCart}
              count={this.state.products.length}
                size={this.state.size}
                sort={this.state.sort}
                filterMemeorySize={this.filterMemeorySize}
                sortProducts={this.sortProducts}
                selectCategory={this.selectCategory}
                category={this.state.category}
                cartItems={this.state.cartItems}
                removeFromCart={this.removeFromCart}
                createOrder={this.createOrder}
                {...props}
              />

<Widget
        handleNewUserMessage={this.handleNewUserMessage}
         profileAvatar={logo}
          title="Ask Kratos"
          titleAvatar={logo}
          subtitle="kratos under your service"
     /> 

              </>
        } />
    <Route exact path='/checkout' render={(props) => <CheckoutLandingPage 
   cartItems={this.state.cartItems}
   removeFromCart={this.removeFromCart}
   createOrder={this.createOrder}
    {...props} />} />
 
      </Switch>
      
     
     {/* {  <Widget
        handleNewUserMessage={this.handleNewUserMessage}
         profileAvatar={logo}
          title="Ask Kratos"
          titleAvatar={logo}
          subtitle="kratos under your service"
     />  } */}
     
         </>   
    );
  }
}

export default App;