import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './App';
import Copy from './copy';
import LandingPage from './components/landingPage'
import { BrowserRouter } from "react-router-dom";

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
    <Copy />
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById('root')
);

