import React, { useState, useEffect } from 'react';
import Container from '@material-ui/core/Container';
import Typography from '@material-ui/core/Typography';
import DraggableContainerElement from './DraggableContainerElement';
import PropTypes from "prop-types";
import { COMPONENT_LABEL } from '../labelConstant';


const DroppableContainer = ({ revertBack, setDraggedUiElementType, userDefinedStyle }) => {

  const [draggedElementName, setDraggedElementName] = useState([]);

  useEffect(() => {
    handleRevertBack(revertBack)
  }, [revertBack])

  const handleRevertBack = (revertFlag) => {
    if (revertFlag) {
      setDraggedElementName([])
    }
  }

  const onDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
  }

  const onDrop = (event) => {
    let typeName = event.dataTransfer.getData("typeName");
    setDraggedUiElementType(typeName);
    setDraggedElementName(oldElements => [...oldElements, typeName]);
  }
  return (
    <React.Fragment>
      <Container id="dropableContainer" className={userDefinedStyle.droppableContainer} fixed onDragOver={(event) => onDragOver(event)}
        onDrop={(event) => onDrop(event)}
      >
        <Typography className={userDefinedStyle.text} variant="h6">
          {COMPONENT_LABEL.BUILD_SECTION}
          {draggedElementName.map(value => {
            return <DraggableContainerElement type={value} key={value} userDefinedStyle={userDefinedStyle} />
          })}
        </Typography>
      </Container>
    </React.Fragment>
  )
}

DroppableContainer.propTypes = {
  revertBack: PropTypes.bool.isRequired,
  setDraggedUiElementType: PropTypes.func.isRequired,
  userDefinedStyle: PropTypes.object.isRequired
}

export default DroppableContainer;