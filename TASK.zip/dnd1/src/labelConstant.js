export const COMPONENT_LABEL = {
    SUBMIT: "Submit",
    AGREE : "Agree",
    SELECT_DOB:"Select Date",
    ENTER_TEXT:"Enter Text",
    HEADING:"UI Builder",
    UI_Element:"UI Element",
    BUILD_SECTION:"BUILD SECTION",
    CLEAR:"clear",
    AUTO_SAVE:"Changes will auto save"
};



export const inputTypes = [
    { name: "Text", icon: "TextFieldsIcon" },
    { name: "DatePicker", icon: "CalendarTodayIcon" },
    { name: "CheckBox", icon: "CheckBoxIcon" },
    { name: "Button", icon: "CheckBoxOutlineBlankIcon" },
  ];


