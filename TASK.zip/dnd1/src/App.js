
import React  from 'react';
import ContainerBox from './containerBox/containerBox';



const App = () =>{

  return (
    <ContainerBox/>
  );

    }
export default App;
