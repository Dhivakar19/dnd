import InputElementBox from '../draggable/InputElementBox';
import DroppableContainer from '../draggable/DroppableContainer';
import React, { useState } from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import { COMPONENT_LABEL } from '../labelConstant';

const useStyles = makeStyles(theme => ({
  offset: theme.mixins.toolbar,
  root: {
    flexGrow: 1,
  },
  appBarbg: {
    backgroundColor: "#0B1F33",
    fontWeight: 2
  },
  droppedElementPadding: {
padding: theme.spacing(2, 0, 0),
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
  droppableContainer: {
    backgroundColor: 'white',
    height: '50vh',
  },
  draggableRoot: {
    display: 'flex',
    flexWrap: 'wrap',
    '& > *': {
      margin: theme.spacing(2),
      width: theme.spacing(25),
      height: theme.spacing(40),
    },
  },
  text: {
    padding: theme.spacing(2, 2, 0),
    color: "black",
    fontWeight: 2
  },
  headingColor: {
    color: "white",
    fontFamily: "Droid Serif",
    flexGrow: 1,
    fontWeight: 25
  },
  autoSave: {
    color: "white",
    fontFamily: "Droid Serif",
    fontWeight: 2
  },
  elementPadding: {
    padding: theme.spacing(4, 2, 0),
  },
  droppableRoot: {
    display: 'flex',
    flexWrap: 'wrap',
    '& > *': {
      margin: theme.spacing(2),
      width: theme.spacing(120),
      height: theme.spacing(40),
    },
  },
}))


const ContainerBox = () => {
  const userDefinedStyle = useStyles();
  const [draggedType, setDraggedType] = useState('');
  const [revertBack, setRevertBack] = useState(false);



  const setDraggedUiElementType = (typeName) => {
    setDraggedType(typeName);
    setRevertBack(false);
  }

  const clearAll = () => {
    setRevertBack(true);
    setDraggedType('');

  }


  return (
    <React.Fragment>
      <AppBar className={userDefinedStyle.appBarbg} position="fixed">
        <Toolbar>
          <Typography variant="h5" className={userDefinedStyle.headingColor} component="h5">
            {COMPONENT_LABEL.HEADING}
          </Typography>
          <Typography variant="h6" className={userDefinedStyle.autoSave} component="h5">
            {COMPONENT_LABEL.AUTO_SAVE}
          </Typography>
        </Toolbar>
      </AppBar>
      <div className={userDefinedStyle.offset} />
      <div className={userDefinedStyle.root}>
        <Grid container spacing={4}>

          <Grid item xs={3} className={userDefinedStyle.draggableRoot}>
            <Paper elevation={6} className={userDefinedStyle.paper}>
              <Typography className={userDefinedStyle.text} variant="h6" gutterBottom={true}>
                {COMPONENT_LABEL.UI_Element}
              </Typography>
              <InputElementBox userDefinedStyle={userDefinedStyle} revertBack={revertBack} draggedType={draggedType} />
            </Paper>
          </Grid>
          <Grid item xs={9} className={userDefinedStyle.droppableRoot}>
            <Paper elevation={6} className={userDefinedStyle.paper} >
              <DroppableContainer userDefinedStyle={userDefinedStyle} revertBack={revertBack} setDraggedUiElementType={setDraggedUiElementType} />
            </Paper>
          </Grid>
          <Grid item xs={7}></Grid>
          <Grid item xs={4}>
            <Button
              variant="contained"
              color="primary"
              onClick={clearAll}
              startIcon={<DeleteForeverIcon />}
            >
              {COMPONENT_LABEL.CLEAR}
            </Button>
          </Grid>
        </Grid>
      </div>

    </React.Fragment>
  );

}
export default ContainerBox;
