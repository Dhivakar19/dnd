import { useState, useEffect } from "react";
import PropTypes from "prop-types";

const ElementDraggable = (element) => {
  const [{ dx, dy }, setOffset] = useState({ dx: 0, dy: 0 });

  useEffect(() => {
    const onMouseClickedOnElement = event => {
      const startX = event.pageX - dx;
      const startY = event.pageY - dy;
      const onMouseDragTheElement = event => {
        const newDx = event.pageX - startX;
        const newDy = event.pageY - startY;
        setOffset({ dx: newDx, dy: newDy });
      };

      document.addEventListener("mousemove", onMouseDragTheElement);

      document.addEventListener(
        "mouseup",
        () => {
          document.removeEventListener("mousemove", onMouseDragTheElement);
        },
        { once: true }
      );
    };

    element && element.current && element.current.addEventListener("mousedown", onMouseClickedOnElement);

    return () => {
      element && element.current && element.current.removeEventListener("mousedown", onMouseClickedOnElement);
    };
  }, [dx, dy]);

  useEffect(() => {
    if (element && element.current) {
      element.current.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
    }
  }, [dx, dy]);

}


ElementDraggable.propTypes = {
  element: PropTypes.element.isRequired
}

export default ElementDraggable;