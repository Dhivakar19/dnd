import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import{AppBar,Toolbar,Typography} from '@material-ui/core';

const useStyles = makeStyles(() => ({

  root: {
    flexGrow: 1,
  },
  title: {
   fontFamily:'Cardo',
   flexGrow: 1,
  },
  toolbar: {
    minHeight:`35px`
  },
  appBarbg: {
    backgroundColor: "#1565c0",
    fontWeight: 2
  },
}));

const LandingHeader = () => {
  const classes = useStyles();
 
  

  return (
    <div className={classes.root}>
      <AppBar className={classes.appBarbg}  position="static">
      <Toolbar>

          <Typography variant="h4" align="center" className={classes.title}>
           Country Search
          </Typography>
            
        </Toolbar>
      </AppBar>
      <div className={classes.toolbar} />
    </div>
  );
}

export default  LandingHeader;
