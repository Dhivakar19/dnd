
import React, { useState, useEffect } from 'react'
import { Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import LandingHeader from './LandingHeader'
import SearchBar from "material-ui-search-bar";
import data from "./data.json";
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Typography from '@material-ui/core/Typography';


const useStyles = makeStyles((theme) => ({
  listItem: {
    padding: theme.spacing(1, 0),
  },
  toolbar: {
    minHeight: `95px`
  },
  root: {
    flexGrow: 1,
  },
  cardRoot: {
    maxWidth: 345,
  },


}));




const App = () => {
  const classes = useStyles();
  const [totalCountry, setTotalCountry] = useState([]);
  const [searchedCountry, setSearchedCountry] = useState('');
  const [filteredCountry, setFilteredCountry] = useState([]);
  const [state, setState] = useState({
    open: false,
    vertical: 'top',
    horizontal: 'center',
  });

  const { vertical, horizontal, open } = state;


  useEffect(() => {
    setTotalCountry(data);
  }, [])


  const  Alert = (props) => {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  
  
  const handleClose = () => {
    setState({ ...state, open: false });
  };

  const onCancel = () => {
    setFilteredCountry([])
  }

  const onHandleSearch = (value) =>{
    const newState = { vertical: 'top', horizontal: 'center' }
    var CountryList;
    CountryList = totalCountry.length!==0  && totalCountry.filter(
      (country) => country.AlphaCode === value.toUpperCase()
    )
    CountryList.length !==0 ? setFilteredCountry([...CountryList]) :  setState({ open: true, ...newState });
  }

  return (
    <React.Fragment>
      <div className={classes.root}>
        <Grid container >
          <Grid xs={12} item>
            <LandingHeader />
          </Grid>
          <Grid xs={12} container item>
            <Grid xs={8} sm={6} md={3} item />
            <Grid xs={4} sm={6} md={8} container item>
              <SearchBar
                value={searchedCountry}
                onChange={(newValue) => setSearchedCountry(newValue)}
                onRequestSearch={() => onHandleSearch(searchedCountry)}
                onCancelSearch={() => onCancel()}
              />

            </Grid>

          </Grid>
          <div className={classes.toolbar} />
          <Grid xs={12} container item>
            <Grid xs={8} sm={6} md={3} item />
            <Grid xs={4} sm={6} md={8} container item>
            { filteredCountry.length!==0 && <List disablePadding>
            <ListItemText primary="Country List" />
          <Typography variant="subtitle1" >
                     
         {filteredCountry.map((countryName,index) => (
          <ListItem className={classes.listItem} key={index}>
            
            <ListItemText primary={countryName.country}  />
          
          </ListItem>
        ))}
          </Typography>
     
     
       
      </List>}

            </Grid>

          </Grid>

        </Grid>
      </div>

      <Snackbar open={open} anchorOrigin={{ vertical, horizontal }} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="error">
      {`Invalid Country code`}
        </Alert>
        </Snackbar>
    </React.Fragment>
  );
}

export default App;
